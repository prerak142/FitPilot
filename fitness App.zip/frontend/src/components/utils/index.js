export const exerciseDescriptions = {
  "Push-Ups": "A bodyweight exercise targeting chest, triceps, and shoulders. Maintain a plank and lower chest to floor.",
  "Dumbbell Press": "A compound chest movement performed with dumbbells for improved balance and stability.",
  "Tricep Dips": "Targets triceps using your own bodyweight on parallel bars or a bench.",
  "Pull-Ups": "Pulling movement using your bodyweight to target the back, biceps, and shoulders.",
  "Barbell Row": "Back-focused compound lift that targets lats, traps, and rear delts.",
  "Bicep Curl": "Isolation movement for building and strengthening the biceps.",
  "Squats": "Key compound movement for legs targeting glutes, quads, and hamstrings.",
  "Lunges": "Leg exercise emphasizing glutes and quads with balance and coordination.",
  "Calf Raises": "Simple exercise to build and tone the calves.",
  "Jumping Jacks": "Full-body cardio warmup that raises heart rate and prepares joints.",
  "Arm Circles": "Shoulder warmup to increase blood flow and joint mobility.",
  "Pull Aparts": "Works the rear deltoids and improves posture with a resistance band.",
  "Band Rows": "Strengthens the back using resistance band with rowing motion.",
  "Leg Swings": "Dynamic warmup for hip mobility and hamstring activation.",
  "Bodyweight Squats": "Warmup movement to activate lower body and prepare joints.",
  "High Knees": "Cardio warmup to boost heart rate and engage.ii core and lower body.",
  "Torso Twists": "Warmup to activate obliques and improve spinal mobility.",
  "Deadlifts": "Compound lift targeting hamstrings, glutes, lower back, and core.",
  "Romanian Deadlifts": "Hamstring and glute-focused variation of the deadlift with a straight-leg motion.",
  "Plank": "Core exercise that strengthens abs, obliques, and lower back.",
  "Bench Press": "Classic compound lift for chest, shoulders, and triceps using a barbell.",
  "Incline Dumbbell Press": "Chest exercise targeting upper pecs with dumbbells on an incline bench.",
  "Overhead Tricep Extension": "Isolation exercise for triceps using a dumbbell or cable overhead."
}

export const gymHealthFacts = [
  "Consistency is key to achieving fitness goals.",
  "Proper hydration enhances workout performance.",
  "Adequate rest is essential for muscle growth.",
  "Tracking progress regularly supports long-term success.",
  "Correct form is more important than lifting heavy weights.",
  "Protein intake supports muscle repair and recovery.",
  "Stretching reduces the risk of injuries.",
  "Quality sleep improves recovery and performance.",
  "Compound lifts maximize strength and muscle gains.",
  "Warmups prepare the body and prevent muscle strains."
]