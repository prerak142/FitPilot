<script setup>
</script>

<template>
  <header>
    <h1 class="text-gradient">Fitness Assistant</h1>
    <nav>
      <router-link to="/">Home</router-link>
      <router-link to="/dashboard">Dashboard</router-link>
      <router-link to="/workouts">Workouts</router-link>
      <router-link to="/diet">Diet</router-link>
      <router-link to="/macros">Macros</router-link>
      <router-link to="/journal">Journal</router-link>
      <router-link to="/ask">Ask AI</router-link>
    </nav>
  </header>

  <main>
    <slot />
  </main>

  <footer>
    <small>Built with Vue 3 and FastAPI</small>
  </footer>
</template>

<style scoped>
:root {
  --background-muted: #f5f5f5;
  --background-primary: #ffffff;
  --color-link: #007bff;
}

header, footer, main {
  padding: 1rem;
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
}

header nav {
  display: flex;
  gap: 1rem;
  margin-top: 1rem;
}

header nav a {
  color: var(--color-link);
  text-decoration: none;
}

header nav a:hover {
  text-decoration: underline;
}

main {
  flex: 1;
}

footer {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  align-items: center;
  padding: 2rem 0 3rem;
}

.text-gradient {
  background: linear-gradient(to right, #007bff, #00ddeb);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}
</style>
