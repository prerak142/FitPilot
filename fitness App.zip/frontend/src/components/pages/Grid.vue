<script setup>
import { ref, computed, onMounted } from 'vue'
import { useUserStore } from '../../stores/user.js'
import axios from 'axios'

const userStore = useUserStore()
const workoutTypes = ['Push', 'Pull', 'Legs']
const workoutProgram = ref({})
const data = ref({})

const props = defineProps({
  handleSelectWorkout: Function,
  firstIncompleteWorkoutIndex: Number,
  handleResetPlan: Function
})

const isWorkoutComplete = computed(() => {
  const currWorkout = data.value?.[props.selectedWorkout]
  return currWorkout && Object.values(currWorkout).every(ex => !!ex)
})

async function fetchWorkoutProgram() {
  if (!userStore.user) {
    console.warn('User data not available, skipping workout fetch')
    return
  }
  try {
    const response = await axios.post('/api/workouts', {
      user_id: userStore.user_id,
      profile: userStore.user.general || {
        age: 30,
        weight: 70,
        height: 170,
        gender: 'Male',
        activity_level: 'Moderate',
        name: ''
      },
      goals: userStore.user.goals || ['Muscle Gain'],
      type: workoutTypes[0]
    })
    workoutProgram.value = parseWorkoutPlan(response.data.workout_plan)
    for (let workoutIdx in workoutProgram.value) {
      data.value[workoutIdx] = {}
      for (let e of workoutProgram.value[workoutIdx].workout) {
        data.value[workoutIdx][e.name] = ''
      }
    }
  } catch (error) {
    console.error('Error fetching workout program:', error)
    workoutProgram.value = {}
  }
}

async function resetWorkoutPlan() {
  try {
    data.value = {}
    await fetchWorkoutProgram()
    props.handleResetPlan()
  } catch (error) {
    console.error('Error resetting workout plan:', error)
  }
}

function parseWorkoutPlan(planText) {
  const lines = planText.split('\n').filter(line => line.trim())
  const program = {}
  let currentDay = null
  let currentSection = null

  for (const line of lines) {
    const dayMatch = line.match(/Day (\d+): (.+)/)
    if (dayMatch) {
      const [, day, type] = dayMatch
      currentDay = parseInt(day) - 1
      program[currentDay] = { type, warmup: [], workout: [] }
      currentSection = null
    } else if (line.includes('Warmup:')) {
      currentSection = 'warmup'
    } else if (line.includes('Workout:')) {
      currentSection = 'workout'
    } else if (currentDay !== null && currentSection && line.trim()) {
      const match = line.match(/(.+?):\s*(\d+)\s*sets,\s*(\d+(?:-\d+)?)\s*reps/)
      if (match) {
        const [, name, sets, reps] = match
        const exercise = { name: name.trim(), sets: parseInt(sets), reps }
        program[currentDay][currentSection].push(exercise)
      }
    }
  }
  return program
}

onMounted(() => {
  if (userStore.user) {
    fetchWorkoutProgram()
  } else {
    userStore.fetchUser().then(fetchWorkoutProgram)
  }
})
</script>
<!-- Rest of the template and style unchanged -->
<style scoped>
#grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 1rem;
  padding: 1rem;
}

#grid button {
  width: 100%;
  padding: 1rem;
  background: #e0e0e0;
  border: none;
  border-radius: 0.5rem;
  text-align: center;
  cursor: pointer;
  transition: background 0.2s ease-in-out;
}

#grid button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.plan-card {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.plan-card-reset {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
}

.plan-card div {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

@media (min-width: 640px) {
  #grid {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
}
</style>