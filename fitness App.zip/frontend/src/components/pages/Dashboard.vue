<script setup>
import Grid from './Grid.vue' // Updated from '../Grid.vue'
import { gymHealthFacts } from '../utils'
import { useUserStore } from '../../stores/user'
import { onMounted, computed } from 'vue'

// Rest of the code remains unchanged
const userStore = useUserStore()
const randomNumber = Math.floor(Math.random() * gymHealthFacts.length)
const todaysFact = gymHealthFacts[randomNumber]

const props = defineProps({
  handleSelectWorkout: Function,
  firstIncompleteWorkoutIndex: Number,
  handleResetPlan: Function
})

onMounted(() => {
  userStore.fetchUser()
})

const userName = computed(() => userStore.user?.general.name || 'User')
</script>

<template>
  <section id="dashboard">
    <div class="card tip-container">
      <h2>Welcome Back, {{ userName }}</h2>
      <div>
        <p class="tip"><strong>Daily Tip</strong><br />{{ todaysFact }}</p>
      </div>
      <button @click="() => handleSelectWorkout(firstIncompleteWorkoutIndex < 0 ? 0 : firstIncompleteWorkoutIndex)" class="start-btn">
        Start Workout
      </button>
    </div>
    <Grid v-bind="props" />
  </section>
</template>

<style scoped>
.tip-container,
.tip-container div,
#dashboard {
  display: flex;
}

.tip-container,
#dashboard {
  flex-direction: column;
}

#dashboard {
  gap: 2rem;
  padding: 1rem;
}

.tip-container {
  gap: 0.5rem;
  padding: 1.5rem;
  background: var(--background-muted);
  border-radius: 0.75rem;
}

.start-btn {
  padding: 0.5rem 1rem;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 0.25rem;
  cursor: pointer;
}

.start-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

@media (min-width: 640px) {
  .tip-container {
    gap: 1rem;
  }
}
</style>