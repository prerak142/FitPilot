<!-- frontend/components/pages/AiAsk.vue -->
<script setup>
import { ref } from 'vue'
import axios from 'axios'

const userQuestion = ref('')
const aiResponse = ref('')
const loading = ref(false)

async function ask() {
  if (!userQuestion.value.trim()) return
  loading.value = true
  aiResponse.value = 'Processing...'
  try {
    const response = await axios.post('/api/ask', { question: userQuestion.value })
    aiResponse.value = response.data.response
  } catch (error) {
    console.error('Error asking AI:', error)
    aiResponse.value = 'Error getting response'
  }
  loading.value = false
}
</script>

<template>
  <section class="card">
    <h2>Ask the AI</h2>
    <input v-model="userQuestion" placeholder="What diet should I follow for muscle gain?" />
    <button @click="ask" :disabled="loading">Ask</button>
    <div v-if="aiResponse">
      <h4>Response:</h4>
      <p>{{ aiResponse }}</p>
    </div>
  </section>
</template>

<style scoped>
.card {
  padding: 1.5rem;
  background: var(--background-muted);
  border-radius: 0.75rem;
  margin: 1rem;
}
input {
  width: 100%;
  padding: 0.5rem;
  margin: 1rem 0;
  border: 1px solid #ccc;
  border-radius: 0.25rem;
}
button {
  padding: 0.5rem 1rem;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 0.25rem;
}
</style>