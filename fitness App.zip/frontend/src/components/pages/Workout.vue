<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import Portal from './Portal.vue'
import { exerciseDescriptions } from '../utils'
import axios from 'axios'
import { useUserStore } from '../../stores/user'
import { useRoute } from 'vue-router'

const route = useRoute()
const userStore = useUserStore()
const selectedExercise = ref(null)
const workoutData = ref({ warmup: [], workout: [], type: '' })
const day = computed(() => parseInt(route.params.day) - 1 || 0)

watch(() => userStore.user, (newUser) => {
  if (newUser) fetchWorkoutPlan()
})

async function fetchWorkoutPlan() {
  if (!userStore.user_id) {
    console.warn('User ID not available, skipping workout fetch')
    return
  }
  try {
    const response = await axios.post('/api/workouts', {
      user_id: userStore.user_id,
      profile: userStore.user,
      goals: userStore.user.goals || ['Weight Loss'],
      type: 'Push'
    })
    workoutData.value = parseWorkoutPlan(response.data.workout_plan)
  } catch (error) {
    console.error('Error fetching workout plan:', error)
  }
}

function parseWorkoutPlan(planText) {
  const lines = planText.split('\n').filter(line => line.trim())
  const program = { warmup: [], workout: [], type: '' }
  let currentSection = null
  for (const line of lines) {
    if (line.includes('Type:')) program.type = line.split(':')[1].trim()
    else if (line.includes('Warmup:')) currentSection = 'warmup'
    else if (line.includes('Workout:')) currentSection = 'workout'
    else if (currentSection && line.trim()) {
      const match = line.match(/(.+?):\s*(\d+)\s*sets,\s*(\d+(?:-\d+)?)\s*reps/)
      if (match) {
        const [, name, sets, reps] = match
        program[currentSection].push({ name: name.trim(), sets: parseInt(sets), reps })
      }
    }
  }
  return program
}

const exerciseDescription = computed(() => exerciseDescriptions[selectedExercise.value] || 'No description available')

function handleCloseModal() {
  selectedExercise.value = null
}

onMounted(() => {
  if (userStore.user) fetchWorkoutPlan()
  else userStore.fetchUser().then(fetchWorkoutPlan)
})
</script>

<template>
  <Portal :handleCloseModal="handleCloseModal" v-if="selectedExercise">
    <div class="exercise-description">
      <h3>{{ selectedExercise }}</h3>
      <div><small>Description</small><p>{{ exerciseDescription }}</p></div>
      <button @click="handleCloseModal">Close</button>
    </div>
  </Portal>

  <section id="workout-card">
    <div class="plan-card card">
      <div class="plan-card-header"><p>Day {{ day < 9 ? '0' + (day + 1) : day + 1 }}</p></div>
      <h2>{{ workoutData.type }} Workout</h2>
    </div>

    <div class="workout-grid">
      <h4 class="grid-name">Warmup</h4><h6>Sets</h6><h6>Reps</h6><h6 class="grid-weights">Weights</h6>
      <div class="workout-grid-row" v-for="(w, wIdx) in workoutData.warmup" :key="'warmup-' + wIdx">
        <div class="grid-name"><p>{{ w.name }}</p><button @click="selectedExercise = w.name">Info</button></div>
        <p>{{ w.sets }}</p><p>{{ w.reps }}</p><input class="grid-weights" placeholder="N/A" type="text" disabled />
      </div>
      <div class="workout-grid-line"></div>
      <h4 class="grid-name">Workout</h4><h6>Sets</h6><h6>Reps</h6><h6 class="grid-weights">Weights</h6>
      <div class="workout-grid-row" v-for="(w, wIdx) in workoutData.workout" :key="'workout-' + wIdx">
        <div class="grid-name"><p>{{ w.name }}</p><button @click="selectedExercise = w.name">Info</button></div>
        <p>{{ w.sets }}</p><p>{{ w.reps }}</p><input v-model="data[day][w.name]" class="grid-weights" placeholder="14kg" type="text" />
      </div>
    </div>

    <div class="card workout-btns">
      <button @click="handleSaveWorkout">Save & Exit</button>
      <button :disabled="!isWorkoutComplete" @click="handleSaveWorkout">Complete</button>
    </div>
  </section>
</template>

<style scoped>
#workout-card, .plan-card { display: flex; flex-direction: column; gap: 1.5rem; }
.plan-card-header, .workout-btns { display: flex; align-items: center; justify-content: space-between; gap: 1rem; }
.workout-grid, .workout-grid-row { display: grid; grid-template-columns: repeat(7, minmax(0, 1fr)); gap: 1rem; }
.workout-grid-row, .workout-grid-line { grid-column: span 7 / span 7; }
.workout-grid-line { margin: 0.5rem 0; height: 3px; border-radius: 2px; background: var(--background-muted); }
.grid-name { grid-column: span 3 / span 3; display: flex; align-items: center; gap: 1rem; }
.grid-weights { grid-column: span 2 / span 2; }
.workout-btns button { flex: 1; padding: 0.5rem; background: #007bff; color: white; border: none; border-radius: 0.25rem; }
</style>