<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../../stores/user'
import { ref } from 'vue'

const router = useRouter()
const userStore = useUserStore()

const profile = ref({
  general: {
    name: '',
    age: null,
    weight: null,
    height: null,
    gender: '',
    activity_level: ''
  },
  goals: []
})

async function saveProfile() {
  if (!profile.value.general.name || !profile.value.general.age || !profile.value.general.weight || 
      !profile.value.general.height || !profile.value.general.gender || !profile.value.general.activity_level || 
      !profile.value.goals.length) {
    alert('Please fill all fields')
    return
  }
  profile.value.goals = profile.value.goals.split(',').map(g => g.trim())
  await userStore.saveUser(profile.value)
  await userStore.fetchUser() // Ensure user is updated
  router.push('/dashboard')
}
</script>

<template>
  <section id="welcome">
    <div class="benefits"><h2>Get Started</h2><div><p>Personalized workouts and diets powered by AI</p><p>Track your progress and goals</p><p>Stay consistent and motivated</p></div></div>
    <div><h3>How It Works</h3><p>Create a custom fitness plan, generate macros, and get smart recommendations.</p></div>
    <div class="card challenge"><h3>Your Journey</h3><p>Complete workouts and log your diet daily to achieve your goals.</p><form @submit.prevent="saveProfile"><input v-model="profile.general.name" placeholder="Name" required /><input v-model.number="profile.general.age" type="number" placeholder="Age" required /><input v-model.number="profile.general.weight" type="number" placeholder="Weight (kg)" required /><input v-model.number="profile.general.height" type="number" placeholder="Height (cm)" required /><select v-model="profile.general.gender" required><option value="">Select Gender</option><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option></select><select v-model="profile.general.activity_level" required><option value="">Select Activity Level</option><option value="Sedentary">Sedentary</option><option value="Moderate">Moderate</option><option value="Active">Active</option></select><input v-model="profile.goals" placeholder="Goals (comma-separated, e.g., Fat Loss,Muscle Gain)" required /><button type="submit">Start Now</button></form></div>
  </section>
</template>

<style scoped>
#welcome, .challenge, .benefits { display: flex; flex-direction: column; }
#welcome { gap: 1.5rem; padding: 1rem; }
.benefits { gap: 0.5rem; }
.challenge { gap: 0.25rem; padding: 1.5rem; background: var(--background-muted); border-radius: 0.75rem; }
form { display: flex; flex-direction: column; gap: 1rem; }
input, select { padding: 0.5rem; border: 1px solid #ccc; border-radius: 0.25rem; }
button { padding: 0.5rem 1rem; background: #007bff; color: white; border: none; border-radius: 0.25rem; cursor: pointer; }
</style>