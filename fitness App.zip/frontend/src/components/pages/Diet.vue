<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useUserStore } from '../../stores/user'

const userStore = useUserStore()
const loading = ref(false)
const dietPlan = ref('')

async function generateDietPlan() {
  if (!userStore.user_id) {
    console.warn('User ID not available, skipping diet fetch')
    return
  }
  loading.value = true
  try {
    const response = await axios.post('/api/diet/', {
      user_id: userStore.user_id,
      profile: userStore.user, // Send the full user object
      goals: userStore.user.goals || ['Weight Loss']
    })
    dietPlan.value = response.data.plan
  } catch (error) {
    console.error('Error fetching diet plan:', error)
    dietPlan.value = 'Error generating diet plan'
  }
  loading.value = false
}

onMounted(() => {
  if (userStore.user) generateDietPlan()
})
</script>

<template>
  <section class="card">
    <h2>Your Diet Plan</h2>
    <button @click="generateDietPlan" :disabled="loading">
      {{ loading ? 'Generating...' : 'Generate Plan' }}
    </button>
    <div v-if="dietPlan" class="diet-output">
      <pre>{{ dietPlan }}</pre>
    </div>
    <p v-else>No plan generated yet.</p>
  </section>
</template>

<style scoped>
.card { padding: 1.5rem; border-radius: 0.75rem; background: var(--background-muted); margin: 1rem; }
button { margin: 1rem 0; padding: 0.5rem 1rem; background: #007bff; color: white; border: none; border-radius: 0.25rem; }
pre { background: #f4f4f4; padding: 1rem; border-radius: 0.5rem; white-space: pre-wrap; }
</style>