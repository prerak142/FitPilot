<!-- frontend/components/pages/Journal.vue -->
<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useUserStore } from '../../stores/user'

const userStore = useUserStore()
const newNote = ref('')
const notes = ref([])

async function addNote() {
  if (newNote.value.trim()) {
    try {
      await axios.post('/api/notes', { user_id: userStore.user_id, text: newNote.value })
      newNote.value = ''
      await fetchNotes()
    } catch (error) {
      console.error('Error saving note:', error)
    }
  }
}

async function deleteNote(index) {
  try {
    await axios.delete(`/api/notes/${userStore.user_id}/${index}`)
    await fetchNotes()
  } catch (error) {
    console.error('Error deleting note:', error)
  }
}

async function fetchNotes() {
  try {
    const response = await axios.get(`/api/notes/${userStore.user_id}`)
    notes.value = response.data.notes
  } catch (error) {
    console.error('Error fetching notes:', error)
  }
}

onMounted(() => {
  if (userStore.user) fetchNotes()
})
</script>

<template>
  <section class="card">
    <h2>Fitness Journal</h2>
    <textarea v-model="newNote" placeholder="Write your progress notes..."></textarea>
    <button @click="addNote">Add Note</button>

    <div class="note" v-for="(note, index) in notes" :key="index">
      <p>{{ note.text }}</p>
      <small>{{ new Date(note.timestamp).toLocaleString() }}</small>
      <button class="delete" @click="deleteNote(index)">Delete</button>
    </div>
  </section>
</template>

<style scoped>
.card {
  padding: 1.5rem;
  background: var(--background-muted);
  border-radius: 0.75rem;
  margin: 1rem;
}
textarea {
  width: 100%;
  min-height: 80px;
  margin: 1rem 0;
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 0.25rem;
}
.note {
  background: #fff;
  padding: 0.75rem;
  border-radius: 0.5rem;
  margin-top: 1rem;
  position: relative;
}
.note .delete {
  position: absolute;
  right: 1rem;
  top: 1rem;
  background: transparent;
  border: none;
  color: red;
}
button {
  padding: 0.5rem 1rem;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 0.25rem;
}
</style>