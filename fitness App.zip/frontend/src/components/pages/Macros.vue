<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useUserStore } from '../../stores/user'

const userStore = useUserStore()
const macros = ref({ calories: 0, protein: 0, fat: 0, carbs: 0 })

async function fetchMacros() {
  if (!userStore.user_id) {
    console.warn('User ID not available, skipping macros fetch')
    return
  }
  try {
    const response = await axios.post('/api/macros', {
      profile: userStore.user,
      goals: userStore.user.goals || ['Muscle Gain']
    })
    macros.value = response.data.macros
  } catch (error) {
    console.error('Error fetching macros:', error)
  }
}

onMounted(() => {
  if (userStore.user) fetchMacros()
  else userStore.fetchUser().then(fetchMacros)
})
</script>

<template>
  <section class="card">
    <h2>Macro Goals</h2>
    <div class="grid">
      <label>Calories <input type="number" v-model="macros.calories" readonly /></label>
      <label>Protein (g) <input type="number" v-model="macros.protein" readonly /></label>
      <label>Fat (g) <input type="number" v-model="macros.fat" readonly /></label>
      <label>Carbs (g) <input type="number" v-model="macros.carbs" readonly /></label>
    </div>
    <button @click="fetchMacros">Regenerate</button>
  </section>
</template>

<style scoped>
.card { padding: 1.5rem; background: var(--background-muted); border-radius: 0.75rem; margin: 1rem; }
.grid { display: grid; gap: 1rem; margin: 1rem 0; }
input { width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 0.25rem; }
button { padding: 0.5rem 1rem; background: #007bff; color: white; border: none; border-radius: 0.25rem; }
</style>