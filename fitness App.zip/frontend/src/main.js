import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router.js'

const app = createApp(App)
const pinia = createPinia()
app.use(pinia)
app.use(router)

// Initialize user data
const { useUserStore } = await import('./stores/user.js')
const userStore = useUserStore()
userStore.fetchUser().then(() => {
  console.log('User store after fetch:', userStore.user)
  app.mount('#app')
}).catch(error => {
  console.error('Failed to fetch user, mounting with default:', error)
  app.mount('#app')
})