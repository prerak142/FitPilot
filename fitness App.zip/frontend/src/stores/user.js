import { defineStore } from 'pinia'
import axios from 'axios'

export const useUserStore = defineStore('user', {
  state: () => ({
    user: null,
    user_id: 1 // Hardcoded for now
  }),
  actions: {
    async fetchUser() {
      try {
        const response = await axios.get('/api/users/1')
        this.user = response.data
      } catch (error) {
        console.error('Error fetching user:', error)
        this.user = null // Default to null if not found
      }
    },
    async saveUser(profile) {
      const flatProfile = {
        name: profile.general.name,
        age: profile.general.age,
        weight: profile.general.weight,
        height: profile.general.height,
        gender: profile.general.gender,
        activity_level: profile.general.activity_level,
        goals: profile.goals
      }
      try {
        const response = await axios.post('/api/users/1', flatProfile)
        this.user = response.data.user || flatProfile
      } catch (error) {
        console.error('Error saving user:', error)
      }
    }
  }
})