// App.vue
<script setup>
import Layout from './components/layouts/Layout.vue'
</script>

<template>
  <Layout>
    <router-view />
  </Layout>
</template>

<style scoped>
main {
  padding: 1rem;
  min-height: 60vh;
}
</style>