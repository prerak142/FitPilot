import { createRouter, createWebHistory } from 'vue-router'
import Welcome from './components/pages/Welcome.vue'
import Dashboard from './components/pages/Dashboard.vue'
import Workout from './components/pages/Workout.vue'
import Diet from './components/pages/Diet.vue'
import Macros from './components/pages/Macros.vue'
import Journal from './components/pages/Journal.vue'
import AiAsk from './components/pages/AiAsk.vue'

const routes = [
  { path: '/', component: Welcome },
  { path: '/dashboard', component: Dashboard },
  { path: '/workouts', component: Workout },
  { path: '/diet', component: Diet },
  { path: '/macros', component: Macros },
  { path: '/journal', component: Journal },
  { path: '/ask', component: AiAsk }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
