from fastapi import APIRouter
from pydantic import BaseModel
from typing import List
from services.generators import generate_workout
from db.database import save_workout, get_workout

router = APIRouter(prefix="/workouts", tags=["Workouts"])

class Profile(BaseModel):
    age: int
    weight: float
    height: float
    gender: str
    activity_level: str
    name: str = ""

class WorkoutRequest(BaseModel):
    user_id: int
    profile: Profile
    goals: List[str]
    type: str

@router.post("/")
async def generate_workout_plan(data: WorkoutRequest):
    result = generate_workout(data.profile.dict(), data.goals)
    save_workout(data.user_id, data.type, result.split("\n"))
    return {"workout_plan": result, "exercises": result.split("\n")}

@router.get("/{user_id}/{type}")
async def get_workout_plan(user_id: int, type: str):
    workouts = get_workout(user_id, type)
    return {"workouts": workouts}