# backend/routes/ask.py
from fastapi import APIRouter
from pydantic import BaseModel
from services.gemini import ask_gemini

router = APIRouter(prefix="/ask", tags=["Ask AI"])

class AskRequest(BaseModel):
    question: str

@router.post("/")
def ask_anything(data: AskRequest):
    prompt = f"""
    You are a helpful and informed fitness and nutrition assistant. Answer the following question clearly and concisely:

    Question: {data.question}

    If the question is vague, provide helpful follow-up suggestions.
    """

    result = ask_gemini(prompt)
    return {"response": result}
