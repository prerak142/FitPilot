from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from services.generators import generate_diet
from db.database import save_diet, get_diet

router = APIRouter(prefix="/diet", tags=["Diet"])

class Profile(BaseModel):
    age: int
    weight: float
    height: float
    gender: str
    activity_level: str
    name: str = ""

class DietRequest(BaseModel):
    user_id: int
    profile: dict  # Changed to dict to accept nested general object
    goals: list[str]

@router.post("/")
def generate_diet_plan(data: DietRequest):
    # Flatten the profile if nested
    flat_profile = data.profile.get("general", data.profile)
    result = generate_diet(flat_profile, data.goals)
    if result.startswith("[Gemini Error]"):
        raise HTTPException(status_code=500, detail=result)
    save_diet(data.user_id, result.split("\n"))
    return {"plan": result}

@router.get("/{user_id}")
def get_diet_plan(user_id: int):
    diets = get_diet(user_id)
    return {"plans": diets}