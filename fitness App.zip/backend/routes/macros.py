from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from services.generators import generate_macros

router = APIRouter(prefix="/macros", tags=["Macros"])

class Profile(BaseModel):
    age: int
    weight: float
    height: float
    gender: str
    activity_level: str
    name: str = ""

class MacroRequest(BaseModel):
    profile: Profile
    goals: list[str]

@router.post("/")
def calculate_macros(data: MacroRequest):
    result = generate_macros(data.profile.dict(), data.goals)
    if result.get("calories") == 0:
        raise HTTPException(status_code=500, detail="Failed to calculate macros")
    return {"macros": result}