from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from db.database import get_user, save_user

router = APIRouter()

class UserUpdate(BaseModel):
    name: str
    age: int
    weight: float
    height: float
    gender: str
    activity_level: str
    goals: list[str]

@router.get("/users/{user_id}")
def get_user_route(user_id: int):
    user = get_user(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.post("/users/{user_id}")
def update_user_route(user_id: int, payload: UserUpdate):
    # Flatten the payload if nested (e.g., from { general: {...}, goals: [...] })
    user_data = {"user_id": user_id}
    for key, value in payload.dict().items():
        if key == "general" and isinstance(value, dict):
            user_data.update(value)
        else:
            user_data[key] = value
    success = save_user(user_id, user_data)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to save user")
    return {
        "message": f"User {user_id} updated successfully.",
        "user": user_data
    }