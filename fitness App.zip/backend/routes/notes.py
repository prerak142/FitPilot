from fastapi import APIRouter
from pydantic import BaseModel
from db.database import add_note, get_notes, delete_note_by_index

router = APIRouter(prefix="/notes", tags=["Notes"])

class Note(BaseModel):
    user_id: int
    text: str

@router.post("/")
def add_note_endpoint(note: Note):
    note_id = add_note(note.user_id, note.text)
    return {"message": "Note added", "note_id": note_id}

@router.get("/{user_id}")
def get_notes_endpoint(user_id: int):
    user_notes = get_notes(user_id)
    return {"notes": user_notes}

@router.delete("/{user_id}/{index}")
def delete_note_endpoint(user_id: int, index: int):
    success = delete_note_by_index(user_id, index)
    if success:
        return {"message": "Note deleted"}
    return {"error": "Note not found"}