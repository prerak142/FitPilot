from .gemini import gemini_chat

def generate_diet(profile: dict, goals: list) -> str:
    prompt = f"""
    Create a personalized Indian diet plan.

    User Profile:
    Name: {profile.get('name')}
    Age: {profile.get('age')} years
    Gender: {profile.get('gender')}
    Weight: {profile.get('weight')} kg
    Height: {profile.get('height')} cm
    Activity Level: {profile.get('activity_level')}
    Goals: {', '.join(goals)}

    Output:
    - 3 meals + 2 snacks (Indian food)
    - Total calories, protein, carbs, fats (approx)
    - Vegetarian by default unless user profile says otherwise
    - Structured as a 7-day plan
    """
    return gemini_chat(prompt)

def generate_macros(profile: dict, goals: list) -> dict:
    prompt = f"""
    Calculate daily macro requirements for the following person:

    Age: {profile.get('age')} years
    Weight: {profile.get('weight')} kg
    Height: {profile.get('height')} cm
    Gender: {profile.get('gender')}
    Activity Level: {profile.get('activity_level')}
    Goals: {', '.join(goals)}

    Output format:
    {{
        "calories": int,
        "protein": int,  # in grams
        "carbs": int,    # in grams
        "fat": int       # in grams
    }}
    """
    response = gemini_chat(prompt)
    try:
        return eval(response.strip())
    except:
        return {"calories": 0, "protein": 0, "carbs": 0, "fat": 0}

def generate_workout(profile: dict, goals: list) -> str:
    prompt = f"""
    Generate a 7-day gym workout plan for the goal(s): {', '.join(goals)}

    Profile:
    - Age: {profile.get('age')}
    - Weight: {profile.get('weight')} kg
    - Height: {profile.get('height')} cm
    - Gender: {profile.get('gender')}
    - Activity Level: {profile.get('activity_level')}

    Format:
    Day 1: ...
    Day 2: ...
    ...
    Include muscle group, 4-5 exercises, sets & reps.
    Make it beginner-friendly.
    """
    return gemini_chat(prompt)