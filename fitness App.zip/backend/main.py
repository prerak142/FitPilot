from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Import route modules
from routes.ask import router as ask_router
from routes.diet import router as diet_router
from routes.macros import router as macros_router
from routes.notes import router as notes_router
from routes.users import router as users_router
from routes.workouts import router as workouts_router

# Initialize FastAPI app
app = FastAPI(
    title="Fitness AI API",
    description="Backend API for the AI-powered fitness and diet recommendation system.",
    version="1.0.0"
)

# Enable CORS for Vite (frontend runs at localhost:5173)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers under /api prefix with trailing slashes
app.include_router(ask_router, prefix="/api", tags=["AI Ask"])
app.include_router(diet_router, prefix="/api", tags=["Diet"])
app.include_router(macros_router, prefix="/api", tags=["Macros"])
app.include_router(notes_router, prefix="/api", tags=["Notes"])
app.include_router(users_router, prefix="/api", tags=["Users"])
app.include_router(workouts_router, prefix="/api", tags=["Workouts"])

# Health check route
@app.get("/", tags=["Root"])
def root():
    return {"message": "Fitness AI API is running"}