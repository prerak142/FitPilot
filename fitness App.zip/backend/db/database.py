from tinydb import TinyDB, Query
from pathlib import Path
from datetime import datetime

# Initialize TinyDB with a JSON file, ensuring the directory exists
DB_PATH = Path("db/db.json")
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
db = TinyDB(DB_PATH)

# Define tables for different entities
users_table = db.table("users")
diets_table = db.table("diets")
workouts_table = db.table("workouts")
notes_table = db.table("notes")

# --- USER OPERATIONS ---
def get_user(user_id: int):
    """Retrieve a user by user_id from the TinyDB users table."""
    User = Query()
    user = users_table.get(User.user_id == user_id)
    return user

def save_user(user_id: int, profile: dict):
    """Save or update a user in the TinyDB users table."""
    User = Query()
    users_table.upsert({"user_id": user_id, **profile}, User.user_id == user_id)
    return True

def delete_user(user_id: int):
    """Delete a user by user_id from the TinyDB users table."""
    User = Query()
    users_table.remove(User.user_id == user_id)
    return True

# --- DIET OPERATIONS ---
def save_diet(user_id: int, diet_plan: list):
    """Save a diet plan for a user in the TinyDB diets table."""
    diet = {"user_id": user_id, "meals": diet_plan, "timestamp": datetime.now().isoformat()}
    return diets_table.insert(diet)

def get_diet(user_id: int):
    """Retrieve all diet plans for a user from the TinyDB diets table."""
    Diet = Query()
    return diets_table.search(Diet.user_id == user_id)

# --- WORKOUT OPERATIONS ---
def save_workout(user_id: int, workout_type: str, exercises: list):
    """Save a workout plan for a user in the TinyDB workouts table."""
    workout = {"user_id": user_id, "type": workout_type, "exercises": exercises, "timestamp": datetime.now().isoformat()}
    return workouts_table.insert(workout)

def get_workout(user_id: int, workout_type: str):
    """Retrieve a workout plan by user_id and type from the TinyDB workouts table."""
    Workout = Query()
    return workouts_table.search((Workout.user_id == user_id) & (Workout.type == workout_type))

# --- NOTE OPERATIONS ---
def get_notes(user_id: int):
    """Retrieve all notes for a user from the TinyDB notes table."""
    Note = Query()
    return notes_table.search(Note.user_id == user_id)

def add_note(user_id: int, text: str):
    """Add a new note for a user in the TinyDB notes table."""
    note = {"user_id": user_id, "text": text, "timestamp": datetime.now().isoformat()}
    return notes_table.insert(note)

def delete_note_by_index(user_id: int, index: int):
    """Delete a note by index for a user from the TinyDB notes table."""
    Note = Query()
    user_notes = notes_table.search(Note.user_id == user_id)
    if 0 <= index < len(user_notes):
        notes_table.remove(doc_ids=[user_notes[index].doc_id])
        return True
    return False